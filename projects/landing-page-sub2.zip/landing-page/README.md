# Landing Page Project

## Table of Contents

* [Instructions](#instructions)
* [Project-Description](#project-description)
* [Usage](#usage)
* [Dependency](#dependencies)


## Instructions
*To navigate to an item, either scroll to it manually or press on the link from the nav bar*


## Project Description
This project is a landing page. In this project we will be manipulating the **DOM** using JS.

## Usage
the landing page code can be used to build navigation bar for any number of sections as well as scrolling smoothly when choosing a page

## Dependencies
functions like getElementsWith__, querySelector 